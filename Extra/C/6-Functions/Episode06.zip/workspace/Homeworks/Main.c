#include <stdio.h>

void work_number_one();
void work_number_two();
void work_number_three();

int main (int argc, const char* argv[]) {
	work_number_one();
	//	work_number_two();
	//	work_number_three();
	return 0;
}
