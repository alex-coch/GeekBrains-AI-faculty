/*
 * Arrays.c
 *
 *  Created on: 11 июн. 2017 г.
 *      Author: ivanovcinnikov
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define ARRAY_LENGTH 10
#define NUMBERS_AMOUNT 1000000

void printArray(int* array, int length) {
	int i;
	for (i = 0; i < length; i++)
			printf("%d ", array[i]);
}

float average(int* array, int length) {
	float result = 0;
	int i;
	for (i = 0; i < length; i++)
		result += *(array + i);

	return result / length;
}

int main (int argc, const char* argv[]) {

	int arr[ARRAY_LENGTH];//[ [][][][][][][][][][] ]
	//arr[0] = 20;			  //[ []                   ]
	//arr[1] = 50;			  //[   []                 ]
	//arr[10] = 60;			  //[                      ][]

	int i = 0;
	while(i < ARRAY_LENGTH) {
		printf("Enter value no.%d:", i);
		scanf("%d", arr + i);
		i++;
	}
	printf("Our array is: ");
	printArray(arr, ARRAY_LENGTH);

	printf("\n And the average is: ");
	printf("%f \n", average(arr, ARRAY_LENGTH));


	/*
	srand(time(NULL));
	int frequency[ARRAY_LENGTH] = {0};
	int a, i;
	for (i = 0; i < NUMBERS_AMOUNT; i++) {
		a = rand() % ARRAY_LENGTH;
		frequency[a]++;
	}

	for (i = 0; i < ARRAY_LENGTH; i++) {
		printf("Number %d generated %6d (%5.2f%%) times \n", i, frequency[i], ((float)frequency[i] / NUMBERS_AMOUNT * 100));
	}
*/
/*	int array1[ARRAY_LENGTH];
	array1[0] = 10;
	array1[1] = 20;
	//....

	int array2[5] = {0, 1, 2, 3, 4};
*/
	return 0;
}
