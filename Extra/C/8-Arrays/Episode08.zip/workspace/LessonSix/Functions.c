/*
 * Functions.c
 *
 *  Created on: 31 мая 2017 г.
 *      Author: ivanovcinnikov
 */
#include <stdio.h>
// copypasted all code from header
#include "header.h"

int sum(int x, int y) {
	int result = x + y;
	return result;
}

int isPrime(int number);

//void somefunction(); //prototype
int main (int argc, const char* argv[]) {
	// more operations here
	int a;
	printf("Enter a number");
	scanf("%d", &a);
	printf("%d\n", sum(50, a));

	int num = 73;
	printf("Введённое число %d %sявляется простым \n", num, isPrime(num) ? "" : "не ");


	return 0;
}

/*
 * Functions.c
 *
 *  Created on: 31 мая 2017 г.
 *      Author: ivanovcinnikov
 */
#include <stdio.h>
// copypasted all code from header
#include "header.h"

int sum(int x, int y) {
	int result = x + y;
	return result;
}

int isPrime(int number);

//void somefunction(); //prototype
int main (int argc, const char* argv[]) {
	// more operations here
	int a;
	printf("Enter a number");
	scanf("%d", &a);
	printf("%d\n", sum(50, a));

	int num = 73;
	printf("Введённое число %d %sявляется простым \n", num, isPrime(num) ? "" : "не ");


	return 0;
}

