/*
 * Arrays.c
 *
 *  Created on: 11 июн. 2017 г.
 *      Author: ivanovcinnikov
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define ARRAY_LENGTH 10
#define NUMBERS_AMOUNT 1000000

int main (int argc, const char* argv[]) {

	srand(time(NULL));
	int frequency[ARRAY_LENGTH] = {0};
	int a, i;
	for (i = 0; i < NUMBERS_AMOUNT; i++) {
		a = rand() % ARRAY_LENGTH;
		frequency[a]++;
	}

	for (i = 0; i < ARRAY_LENGTH; i++) {
		printf("Number %d generated %6d (%5.2f%%) times \n", i, frequency[i], ((float)frequency[i] / NUMBERS_AMOUNT * 100));
	}

/*	int array1[ARRAY_LENGTH];
	array1[0] = 10;
	array1[1] = 20;
	//....

	int array2[5] = {0, 1, 2, 3, 4};
*/
	return 0;
}
